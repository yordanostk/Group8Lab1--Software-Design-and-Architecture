/**
 * Abstract class Observer that defines a standard update method.
 * This class is designed to be extended by any class that needs to observe changes in a Subject.
 */
public abstract class Observer {

    /**
     * Abstract method update that must be implemented by subclasses.
     * This method is called whenever the Subject (the object being observed) changes.
     *
     * @param discount the new discount value that observers are being notified about.
     */
    public abstract void update (float discount);
}







