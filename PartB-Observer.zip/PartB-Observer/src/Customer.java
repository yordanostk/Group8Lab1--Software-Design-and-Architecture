/**
 * The Customer class extends the Observer abstract class, allowing it to receive updates from a Store object.
 * This class is specifically tailored to handle notifications from the Store to which it is registered.
 */
public class Customer extends Observer {

    private String name; // Name of the customer
    private Store favoriteStore; // Store object that the customer observes
    private float currentDiscount; // Current discount rate received from the store

    /**
     * Constructs a new Customer object with a specified name and associated store.
     *
     * @param name           the name of the customer
     * @param favoriteStore  the store that the customer will observe
     */
    public Customer(String name, Store favoriteStore) {
        this.name = name;
        this.favoriteStore = favoriteStore;
    }

    /**
     * Update method that is called when the observed Store changes its discount.
     * This method updates the customer's record of the current discount and prints a notification.
     *
     * @param discount the new discount percentage from the store
     */
    @Override
    public void update(float discount) {
        this.currentDiscount = discount;
        System.out.println(name + " received a discount update: " + discount + "%");
    }

    /**
     * Registers this customer as an observer of its favorite store.
     */
    public void register() {
        favoriteStore.registerObserver(this);
    }

    /**
     * Unregisters this customer from observing its favorite store.
     */
    public void unregister() {
        favoriteStore.unregisterObserver(this);
    }
}
