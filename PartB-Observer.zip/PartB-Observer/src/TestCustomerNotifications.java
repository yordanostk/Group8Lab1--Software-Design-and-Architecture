/**
 * Test class to demonstrate the Observer pattern in action with the Store and Customer classes.
 * This class contains the main method to execute the observer pattern test.
 */
public class TestCustomerNotifications {
    public static void main(String[] args) {
        // Create a new Store object
        Store store = new Store();

        // Create two Customer objects, Alice and Bob, observing the same Store
        Customer alice = new Customer("Alice", store);
        Customer bob = new Customer("Bob", store);

        // Register Alice and Bob as observers to the store
        alice.register();
        bob.register();

        // Set the store's discount to 10%, notifying both registered observers, Alice and Bob
        store.setDiscount(10); // Both Alice and Bob will be notified

        // Unregister Bob so he no longer receives updates from the store
        bob.unregister();

        // Set the store's discount to 20%, now only notifying Alice as Bob is no longer registered
        store.setDiscount(20); // Only Alice will be notified
    }
}

