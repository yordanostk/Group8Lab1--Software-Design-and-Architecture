/**
 * 
 */
/**
 * @author 100300936
 *
 */
package tryObserver;