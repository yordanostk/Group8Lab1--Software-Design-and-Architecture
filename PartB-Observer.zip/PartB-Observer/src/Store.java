import java.util.ArrayList;
import java.util.List;

/**
 * The Store class maintains a list of observers and notifies them of changes, particularly discount updates.
 * This class uses the Observer design pattern to allow for dynamic and efficient updates to interested parties (observers).
 */
public class Store {
	private List<Observer> observers = new ArrayList<>(); // List to hold all registered observers
	private float discount; // Current discount percentage that the store offers

	/**
	 * Registers an observer to receive updates.
	 * This method adds the observer to the list of registered observers.
	 *
	 * @param observer the observer to be added to the list
	 */
	public void registerObserver(Observer observer) {
		observers.add(observer);
	}

	/**
	 * Unregisters an observer so that it no longer receives updates.
	 * This method removes the observer from the list of registered observers.
	 *
	 * @param observer the observer to be removed from the list
	 */
	public void unregisterObserver(Observer observer) {
		observers.remove(observer);
	}

	/**
	 * Notifies all registered observers of the current discount update.
	 * This method is called whenever the discount is updated.
	 */

	/**
	 * Notifies all registered observers of the current discount update.
	 * This method is called whenever the discount is updated.
	 */
	protected void notifyObservers() {
		for (Observer observer : observers) {
			observer.update(discount);
		}
	}

	/**
	 * Sets the discount for the store and notifies all observers of this change.
	 * This method updates the store's discount and triggers a notification to all registered observers.
	 *
	 * @param discount the new discount rate to be set
	 **/
	public void setDiscount(float discount) {
		this.discount = discount;
		notifyObservers();
	}
}