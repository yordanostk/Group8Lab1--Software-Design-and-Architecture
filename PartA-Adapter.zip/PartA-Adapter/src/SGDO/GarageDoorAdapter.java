package SGDO;

// The GarageDoorAdapter class implements the StdGarageDoorOpener interface,
// adapting a standard garage door (BasicGarageDoor) to work with a premium garage door (PremiumGarageDoorOpener).
public class GarageDoorAdapter implements StdGarageDoorOpener {

    // The standard garage door object (basic model).
    private BasicGarageDoor basicGarageDoor;

    // The premium garage door opener object (advanced model).
    private PremiumGarageDoorOpener premiumGarageDoor;

    // Fixed speed to control how fast the premium door will operate.
    private int fixedSpeed;

    // Constructor that takes a BasicGarageDoor, PremiumGarageDoorOpener, and a speed value.
    // The speed value will be used to operate the premium door, while the basic door will always function at a standard speed.
    public GarageDoorAdapter(BasicGarageDoor basicGarageDoor, PremiumGarageDoorOpener premiumGarageDoor, int speed) {
        this.premiumGarageDoor = premiumGarageDoor;  // Assign the premium door opener
        this.basicGarageDoor = basicGarageDoor;      // Assign the basic door
        this.fixedSpeed = speed;                     // Set the fixed speed for the premium door
    }

    // The openDoor method adapts the standard open operation to the premium garage door's open function.
    // It first opens the basic garage door, then opens the premium door at the provided speed.
    @Override
    public void openDoor() {
        System.out.println("Adapting BasicGarageDoor open to PremiumGarageDoor's open method.");
        basicGarageDoor.openDoor();                   // Opens the basic garage door
        premiumGarageDoor.openDoor(fixedSpeed);       // Opens the premium garage door with the fixed speed
    }

    // The closeDoor method adapts the standard close operation to the premium garage door's close function.
    // It first closes the basic garage door, then closes the premium door at the provided speed.
    @Override
    public void closeDoor() {
        System.out.println("Adapting BasicGarageDoor close to PremiumGarageDoor's close method.");
        basicGarageDoor.closeDoor();                  // Closes the basic garage door
        premiumGarageDoor.closeDoor(fixedSpeed);      // Closes the premium garage door with the fixed speed
    }
}

