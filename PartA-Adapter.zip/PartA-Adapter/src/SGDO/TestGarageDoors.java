package SGDO;

public class TestGarageDoors {
    public static void main(String[] args) {
        // Creating an instance of BasicGarageDoor (the standard model).
        BasicGarageDoor standardDoor = new BasicGarageDoor();

        // Creating an instance of PremiumGarageDoorOpener (the premium model).
        PremiumGarageDoorOpener premiumGarageDoor = new PremiumGarageDoorOpener();

        // Testing the basic garage door directly without any adaptation.
        System.out.println("Testing Basic Garage Door:");
        standardDoor.openDoor();    // Opening the basic garage door
        standardDoor.closeDoor();   // Closing the basic garage door

        // Creating an instance of GarageDoorAdapter to adapt the standard door behavior to the premium door behavior.
        // The adapter is initialized with a fixed speed of 5 for premium garage door operations.
        GarageDoorAdapter adaptedGarageDoor = new GarageDoorAdapter(standardDoor, premiumGarageDoor, 5); // Fixed speed of 5

        // Testing the premium garage door operations through the adapter.
        System.out.println("\nTesting premium garage door through adapter:");
        adaptedGarageDoor.openDoor();    // Adapting and opening the premium garage door with fixed speed
        adaptedGarageDoor.closeDoor();   // Adapting and closing the premium garage door with fixed speed
    }
}
