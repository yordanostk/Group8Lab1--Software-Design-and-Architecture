package SGDO;

public interface StdGarageDoorOpener {

	public void openDoor();

	public void closeDoor();

}
